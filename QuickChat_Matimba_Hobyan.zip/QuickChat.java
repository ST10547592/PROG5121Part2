package za.ac.quickchat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Console entry point for the Part 2 QuickChat application.
 */
public class QuickChat {
    private static final Scanner INPUT = new Scanner(System.in);
    private static final List<Message> MESSAGES = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("=== QuickChat Login ===");
        System.out.print("Create a username for this session: ");
        String registeredUsername = INPUT.nextLine().trim();
        System.out.print("Create a password for this session: ");
        String registeredPassword = INPUT.nextLine();

        System.out.println("\nPlease log in.");
        boolean loggedIn = false;
        for (int attempt = 1; attempt <= 3; attempt++) {
            System.out.print("Username: ");
            String username = INPUT.nextLine().trim();
            System.out.print("Password: ");
            String password = INPUT.nextLine();

            if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
                loggedIn = true;
                System.out.println("Login successful.");
                break;
            }
            System.out.println("Username or password incorrect, please try again.");
        }

        if (!loggedIn) {
            System.out.println("Login failed. QuickChat will close.");
            return;
        }

        System.out.println("Welcome to QuickChat.");
        boolean running = true;
        while (running) {
            displayMenu();
            int option = readInt("Choose an option: ");

            switch (option) {
                case 1:
                    sendMessages();
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    running = false;
                    System.out.println("Thank you for using QuickChat.");
                    break;
                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\n1) Send Messages");
        System.out.println("2) Show recently sent messages");
        System.out.println("3) Quit");
    }

    private static void sendMessages() {
        int numberOfMessages = readInt("How many messages would you like to enter? ");
        while (numberOfMessages < 1) {
            System.out.println("Please enter a number greater than zero.");
            numberOfMessages = readInt("How many messages would you like to enter? ");
        }

        int sentCount = 0;
        for (int i = 1; i <= numberOfMessages; i++) {
            System.out.println("\n--- Message " + i + " of " + numberOfMessages + " ---");
            String recipient;
            while (true) {
                System.out.print("Recipient number (format +27XXXXXXXXX): ");
                recipient = INPUT.nextLine().trim();
                Message check = new Message(i, "0000000000", recipient, "");
                String validation = check.checkRecipientCell();
                if (validation.equals("Cell phone number successfully captured.")) {
                    System.out.println(validation);
                    break;
                }
                System.out.println(validation);
            }

            System.out.print("Enter your message (maximum 250 characters): ");
            String text = INPUT.nextLine();
            Message message = new Message(i, recipient, text);

            String lengthResult = message.validateMessageLength();
            while (!lengthResult.equals("Message ready to send.")) {
                System.out.println(lengthResult);
                System.out.print("Enter a shorter message (maximum 250 characters): ");
                text = INPUT.nextLine();
                message = new Message(i, recipient, text);
                lengthResult = message.validateMessageLength();
            }
            System.out.println(lengthResult);
            System.out.println("Message ID generated: " + message.getMessageId());
            System.out.println("Message Hash: " + message.getMessageHash());

            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");

            int action;
            while (true) {
                action = readInt("Choose an action: ");
                if (action >= 1 && action <= 3) {
                    break;
                }
                System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }

            String actionResult = message.sentMessage(action);
            System.out.println(actionResult);

            if (action == 1) {
                sentCount++;
            } else if (action == 3) {
                try {
                    storeMessage(message);
                } catch (IOException exception) {
                    System.out.println("Could not store the message: " + exception.getMessage());
                }
            }

            MESSAGES.add(message);
            System.out.println("\n" + message.printMessages());
        }

        System.out.println("\nTotal messages sent: " + sentCount);
    }

    private static void storeMessage(Message message) throws IOException {
        Path file = Path.of("stored_messages.json");
        String existing = Files.exists(file)
                ? Files.readString(file, StandardCharsets.UTF_8).trim() : "";

        String object = message.toJson();
        String updated;
        if (existing.isEmpty() || existing.equals("[]")) {
            updated = "[\n  " + object + "\n]";
        } else {
            String content = existing.substring(0, existing.length() - 1).trim();
            updated = content + ",\n  " + object + "\n]";
        }
        Files.writeString(file, updated, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException exception) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
