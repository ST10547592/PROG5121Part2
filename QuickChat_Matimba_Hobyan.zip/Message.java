package za.ac.quickchat;

import java.security.SecureRandom;
import java.util.Locale;

/**
 * Represents one message in QuickChat.
 */
public class Message {
    private static final SecureRandom RANDOM = new SecureRandom();

    private final String messageId;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;
    private final String messageHash;
    private String status;

    public Message(int messageNumber, String recipient, String messageText) {
        this(messageNumber, generateMessageId(), recipient, messageText);
    }

    // Constructor with an ID is useful for predictable unit tests.
    public Message(int messageNumber, String messageId, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.messageId = messageId;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
        this.status = "Pending";
    }

    public static String generateMessageId() {
        long value = 1_000_000_000L + (long) (RANDOM.nextDouble() * 9_000_000_000L);
        return String.valueOf(value);
    }

    public boolean checkMessageID() {
        return messageId != null && messageId.matches("\\d{1,10}");
    }

    public String checkRecipientCell() {
        // South African international format: +27 followed by nine digits.
        if (recipient != null && recipient.matches("\\+27\\d{9}")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String validateMessageLength() {
        if (messageText == null) {
            return "Message ready to send.";
        }
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        }
        return "Message exceeds 250 characters by " + (messageText.length() - 250)
                + "; please reduce the size.";
    }

    public String createMessageHash() {
        String firstTwoDigits = messageId != null && messageId.length() >= 2
                ? messageId.substring(0, 2) : "00";
        String firstWord = "";
        String lastWord = "";

        if (messageText != null && !messageText.trim().isEmpty()) {
            String[] words = messageText.trim().split("\\s+");
            firstWord = words[0].replaceAll("[^A-Za-z0-9]", "");
            lastWord = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        }

        return (firstTwoDigits + ":" + messageNumber + ":" + firstWord + lastWord)
                .toUpperCase(Locale.ROOT);
    }

    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                status = "Sent";
                return "Message successfully sent.";
            case 2:
                status = "Disregarded";
                return "Press 0 to delete the message.";
            case 3:
                status = "Stored";
                return "Message successfully stored.";
            default:
                return "Invalid option. Choose 1, 2, or 3.";
        }
    }

    public String printMessages() {
        return "Message ID: " + messageId
                + System.lineSeparator() + "Message Hash: " + messageHash
                + System.lineSeparator() + "Recipient: " + recipient
                + System.lineSeparator() + "Message: " + messageText;
    }

    public int returnTotalMessagess() {
        return "Sent".equals(status) ? 1 : 0;
    }

    public String toJson() {
        return "{" +
                "\"messageId\":\"" + escapeJson(messageId) + "\"," +
                "\"messageNumber\":" + messageNumber + "," +
                "\"messageHash\":\"" + escapeJson(messageHash) + "\"," +
                "\"recipient\":\"" + escapeJson(recipient) + "\"," +
                "\"message\":\"" + escapeJson(messageText) + "\"," +
                "\"status\":\"" + escapeJson(status) + "\"" +
                "}";
    }

    private static String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    public String getMessageId() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
    public String getStatus() { return status; }
}
