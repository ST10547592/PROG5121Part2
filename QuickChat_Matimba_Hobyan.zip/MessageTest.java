package za.ac.quickchat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MessageTest {

    @Test
    void messageIdMustNotExceedTenDigits() {
        Message valid = new Message(1, "1234567890", "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        Message invalid = new Message(1, "12345678901", "+27718693002", "Hello");
        assertTrue(valid.checkMessageID());
        assertFalse(invalid.checkMessageID());
    }

    @Test
    void recipientNumberMustUseSouthAfricanInternationalFormat() {
        Message valid = new Message(1, "1234567890", "+27718693002", "Hello");
        Message invalid = new Message(1, "1234567890", "08575975889", "Hello");
        assertEquals("Cell phone number successfully captured.", valid.checkRecipientCell());
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                invalid.checkRecipientCell());
    }

    @Test
    void messageMustNotExceed250Characters() {
        Message valid = new Message(1, "0012345678", "+27718693002", "Hi Mike");
        Message invalid = new Message(1, "0012345678", "+27718693002", "a".repeat(253));
        assertEquals("Message ready to send.", valid.validateMessageLength());
        assertEquals("Message exceeds 250 characters by 3; please reduce the size.",
                invalid.validateMessageLength());
    }

    @Test
    void messageHashUsesFirstTwoIdDigitsMessageNumberAndFirstLastWords() {
        Message message = new Message(0, "0012345678", "+27718693002",
                "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", message.createMessageHash());
    }

    @Test
    void messageActionReturnsRequiredMessages() {
        Message sent = new Message(1, "1234567890", "+27718693002", "Hello");
        Message disregarded = new Message(2, "1234567891", "+27718693002", "Hello");
        Message stored = new Message(3, "1234567892", "+27718693002", "Hello");

        assertEquals("Message successfully sent.", sent.sentMessage(1));
        assertEquals("Press 0 to delete the message.", disregarded.sentMessage(2));
        assertEquals("Message successfully stored.", stored.sentMessage(3));
    }

    @Test
    void generatedMessageIdHasTenDigits() {
        String id = Message.generateMessageId();
        assertTrue(id.matches("\\d{10}"));
    }
}
